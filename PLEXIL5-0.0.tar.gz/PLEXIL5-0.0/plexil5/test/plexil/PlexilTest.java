package plexil;

import org.junit.Test;

public class PlexilTest {
	
	@Test
	public void test1() throws Exception {
		PlexilTreeParser tree = new PlexilTreeParser();
		
		LiteralASTNode t = new LiteralASTNode();
		t.ttype = 39;
		
		tree.booleanValue(t);
	}

}
