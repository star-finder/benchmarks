package plexil;

public class Ple2XMLProcessingException extends Exception {

	public Ple2XMLProcessingException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public Ple2XMLProcessingException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
