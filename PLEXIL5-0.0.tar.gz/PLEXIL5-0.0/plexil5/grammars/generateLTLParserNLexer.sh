java -cp ../lib/antlrworks-1.4.2.jar org.antlr.Tool LTLPlexil5.g -o ../src/org/nianet/plexil5/maude2java/modelchecking/ltlparser/antlrgrammar																		      
