PLEXIL5 
========

### Requirements

* Apache Ant

* [Maude Interpreter Binaries](http://maude.cs.uiuc.edu/download/). Copy maude.linux64, maude.linux, maude.intelDarwin to 'plexilite' folder.



### Compiling and running

In 'build' directory:

```bash
$ ant run
```


